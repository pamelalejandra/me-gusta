
function cuenta(contador){
    let elemento = document.querySelector(contador);
    let sumando=elemento.innerText;
    sumando++;
    elemento.innerText=sumando;
}

cuenta()